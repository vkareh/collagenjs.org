#!/usr/bin/env node

var collagen = require('collagen');

// Add functionality modules here...

collagen.load(__dirname);

// Add override modules here...

collagen.start();
