view = views.Page.extend();

views.CollagenNavBar.augment({
    menuItems: [
        {path: '/about', label: 'About', weight: 1}
    ]
});
