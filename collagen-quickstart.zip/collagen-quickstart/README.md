Collagen.js Quickstart
======================

Use this package to get up and running with [Collagen.js](http://collagenjs.org).

Download this package by running `git clone git://github.com/vkareh/collagen-quickstart.git`.

Run `npm install` to get a working instance.

Run `node index.js` to start the website and navigate to [http://localhost:3000](http://localhost:3000) to view your new website.

Go to the [Collagen.js website](http://collagenjs.org) to learn more about this framework.
